#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日监控扫描模块（GitHub Actions 版）
- 读取 pool.txt 动态股票池
- 扫描四类信号：价量扳机 / 互动易 / 公告 / 人气榜
- 输出 docs/data/latest.json + history.json 供 PWA 消费
海外 IP 容错：单数据源失败不影响整体，错误记录到 errors 数组
"""
import json
import re
import sys
import time
import warnings
from datetime import datetime, timedelta
from pathlib import Path

warnings.filterwarnings("ignore")
import pandas as pd
import requests

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "docs" / "data"
DATA.mkdir(parents=True, exist_ok=True)
POOL = BASE / "pool.txt"

BULLISH_KEYWORDS = [
    "中标", "订单", "合同", "签约", "合作", "量产", "投产", "产能", "扩产",
    "提价", "涨价", "新品", "新产品", "认证", "突破", "首次", "获批", "专利",
    "回购", "增持", "重组", "收购", "并购", "定增", "股权激励", "业绩预增",
    "净利润增长", "扭亏", "超预期", "战略合作", "框架协议", "独家供应",
]
RISK_KEYWORDS = [
    "减持", "问询函", "监管", "处罚", "诉讼", "亏损", "业绩预减", "退市",
    "澄清", "不实", "风险提示", "停牌", "立案",
]

errors = []
source_status = {}


def log_error(source, msg):
    errors.append({"source": source, "msg": str(msg)[:200], "time": datetime.now().strftime("%H:%M:%S")})


def load_stocks():
    """从 pool.txt 读取股票池，支持 # 注释和空行"""
    stocks = []
    seen = set()
    if not POOL.exists():
        log_error("pool", f"股票池文件不存在: {POOL}")
        return stocks
    for line in POOL.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"[,，\s]+", line)
        if len(parts) < 2:
            log_error("pool", f"格式错误行: {line}")
            continue
        code, name = parts[0].strip(), parts[1].strip()
        code = re.sub(r"\D", "", code)
        if len(code) != 6:
            log_error("pool", f"代码非6位: {line}")
            continue
        if code in seen:
            continue
        seen.add(code)
        stocks.append({"code": code, "name": name})
    return stocks


def scan_irm(stocks, days=3):
    """互动易问答（仅深市）"""
    results = []
    try:
        import akshare as ak
    except Exception as e:
        log_error("irm", f"akshare导入失败: {e}")
        return results
    cutoff = datetime.now() - timedelta(days=days)
    ok = fail = 0
    for s in stocks:
        code = s["code"]
        if code.startswith("6"):
            continue
        try:
            df = ak.stock_irm_cninfo(code)
            if df is None or df.empty:
                ok += 1
                continue
            df["更新时间"] = pd.to_datetime(df["更新时间"], errors="coerce")
            new = df[df["更新时间"] >= cutoff]
            for _, r in new.iterrows():
                text = str(r.get("回答内容") or r.get("问题") or "")
                hits = [k for k in BULLISH_KEYWORDS if k in text]
                risks = [k for k in RISK_KEYWORDS if k in text]
                signal = "利好:" + "/".join(hits) if hits else ("风险:" + "/".join(risks) if risks else "一般")
                results.append({
                    "code": code, "name": s["name"], "source": "互动易",
                    "signal": signal, "time": str(r["更新时间"])[:19], "text": text[:160],
                })
            ok += 1
        except Exception as e:
            fail += 1
            log_error("irm", f"{code}: {type(e).__name__}")
        time.sleep(0.1)
    source_status["irm"] = {"ok": ok, "fail": fail}
    return results


def scan_notices(stocks, days=3):
    """公告扫描（全市场按日 + 本地过滤）"""
    results = []
    try:
        import akshare as ak
    except Exception as e:
        log_error("notice", f"akshare导入失败: {e}")
        return results
    target = {s["code"]: s["name"] for s in stocks}
    seen = set()
    ok = fail = 0
    for d in range(days):
        date = (datetime.now() - timedelta(days=d)).strftime("%Y%m%d")
        try:
            df = ak.stock_notice_report(date=date)
            if df is None or df.empty:
                ok += 1
                continue
            df["代码"] = df["代码"].astype(str).str.zfill(6)
            sub = df[df["代码"].isin(target)]
            for _, r in sub.iterrows():
                key = (r["代码"], r["公告标题"])
                if key in seen:
                    continue
                seen.add(key)
                title = str(r["公告标题"])
                hits = [k for k in BULLISH_KEYWORDS if k in title]
                risks = [k for k in RISK_KEYWORDS if k in title]
                signal = "利好:" + "/".join(hits) if hits else ("风险:" + "/".join(risks) if risks else "一般")
                results.append({
                    "code": r["代码"], "name": target[r["代码"]], "source": "公告",
                    "signal": signal, "time": str(r["公告日期"]), "text": title[:160],
                })
            ok += 1
        except Exception as e:
            fail += 1
            log_error("notice", f"{date}: {type(e).__name__}")
        time.sleep(0.15)
    source_status["notice"] = {"ok": ok, "fail": fail}
    return results


def check_price_trigger(stocks):
    """价量扳机 + 获取最新价格"""
    results = []
    try:
        import akshare as ak
    except Exception as e:
        log_error("price", f"akshare导入失败: {e}")
        return results
    end = datetime.now().strftime("%Y%m%d")
    start = (datetime.now() - timedelta(days=200)).strftime("%Y%m%d")
    ok = fail = 0
    for s in stocks:
        code = s["code"]
        sym = ("sh" if code.startswith(("6", "9")) else "sz") + code
        try:
            df = ak.stock_zh_a_daily(symbol=sym, start_date=start, end_date=end, adjust="qfq")
            if df is None or len(df) < 60:
                fail += 1
                continue
            df = df.sort_values("date").reset_index(drop=True)
            last = df.iloc[-1]
            prev = df.iloc[-2] if len(df) > 1 else last
            high60 = df["close"].iloc[:-1].tail(60).max()
            vol_ma20 = df["volume"].iloc[:-1].tail(20).mean()
            vr = float(last["volume"]) / vol_ma20 if vol_ma20 > 0 else 0
            breakout = last["close"] > high60
            triggered = bool(breakout and vr > 1.5)
            change = (float(last["close"]) / float(prev["close"]) - 1) * 100 if prev["close"] else 0
            results.append({
                "code": code, "name": s["name"], "source": "价量",
                "price": round(float(last["close"]), 2),
                "change": round(change, 2),
                "high60": round(float(high60), 2),
                "vol_ratio": round(vr, 2),
                "breakout": bool(breakout),
                "trigger": triggered,
                "date": str(last["date"])[:10],
            })
            ok += 1
        except Exception as e:
            fail += 1
            log_error("price", f"{code}: {type(e).__name__}")
        time.sleep(0.1)
    source_status["price"] = {"ok": ok, "fail": fail}
    return results


def check_heat(stocks):
    """人气榜热度"""
    H = {"User-Agent": "Mozilla/5.0", "Content-Type": "application/json",
         "Referer": "https://guba.eastmoney.com/"}
    results = []
    ok = fail = 0
    for s in stocks:
        code = s["code"]
        prefix = "SH" if code.startswith(("6", "9")) else "SZ"
        payload = {"appId": "appId01", "globalId": "786e4c21-70dc-435a-93bb-38",
                   "marketType": "", "srcSecurityCode": prefix + code, "yearType": "5"}
        try:
            r = requests.post("https://emappdata.eastmoney.com/stockrank/getHisList",
                              json=payload, headers=H, timeout=12)
            data = r.json().get("data") or []
            if len(data) < 10:
                fail += 1
                continue
            ranks = sorted([(x["calcTime"], x["rank"]) for x in data])
            recent = ranks[-1][1]
            avg20 = sum(r[1] for r in ranks[-20:]) / 20
            signal = ""
            if recent < avg20 * 0.6:
                signal = "热度飙升-警惕兑现"
            elif recent > avg20 * 1.5:
                signal = "冷门-观察"
            results.append({
                "code": code, "name": s["name"], "source": "人气榜",
                "rank": recent, "avg20": round(avg20, 0), "signal": signal,
                "date": ranks[-1][0],
            })
            ok += 1
        except Exception as e:
            fail += 1
            log_error("heat", f"{code}: {type(e).__name__}")
        time.sleep(0.15)
    source_status["heat"] = {"ok": ok, "fail": fail}
    return results


def build_output(stocks, price_data, irm_data, notice_data, heat_data):
    """聚合成 PWA 需要的结构"""
    price_map = {r["code"]: r for r in price_data}
    heat_map = {r["code"]: r for r in heat_data}

    stock_list = []
    for s in stocks:
        p = price_map.get(s["code"], {})
        h = heat_map.get(s["code"], {})
        stock_list.append({
            "code": s["code"], "name": s["name"],
            "price": p.get("price"), "change": p.get("change"),
            "high60": p.get("high60"), "vol_ratio": p.get("vol_ratio"),
            "breakout": p.get("breakout", False), "trigger": p.get("trigger", False),
            "heat_rank": h.get("rank"), "heat_signal": h.get("signal", ""),
        })

    triggers = [r for r in price_data if r.get("trigger")]
    bullish = [r for r in irm_data + notice_data if r.get("signal", "").startswith("利好")]
    risks = [r for r in irm_data + notice_data + heat_data
             if "风险" in r.get("signal", "") or "热度飙升" in r.get("signal", "")]

    return {
        "scan_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "pool_size": len(stocks),
        "triggers": triggers,
        "bullish": bullish,
        "risks": risks,
        "stocks": stock_list,
        "source_status": source_status,
        "errors": errors[:30],
        "disclaimer": "消息线索只进观察名单；价量扳机才是执行信号。热度飙升是减仓/回避信号。",
    }


def update_history(output):
    """更新历史统计"""
    hist_file = DATA / "history.json"
    history = []
    if hist_file.exists():
        try:
            history = json.load(open(hist_file, encoding="utf-8"))
        except Exception:
            history = []
    today = datetime.now().strftime("%Y-%m-%d")
    entry = {
        "date": today,
        "triggers": len(output["triggers"]),
        "trigger_codes": [r["code"] for r in output["triggers"]],
        "bullish": len(output["bullish"]),
        "risks": len(output["risks"]),
        "pool_size": output["pool_size"],
    }
    history = [h for h in history if h.get("date") != today]
    history.append(entry)
    history = sorted(history, key=lambda x: x["date"])[-90:]
    json.dump(history, open(hist_file, "w", encoding="utf-8"), ensure_ascii=False, indent=2)


def main():
    args = sys.argv[1:]
    quick = "--quick" in args
    days = 3
    if "--days" in args:
        try:
            days = int(args[args.index("--days") + 1])
        except Exception:
            pass

    stocks = load_stocks()
    print(f"股票池: {len(stocks)} 只")
    if not stocks:
        print("股票池为空，退出")
        return

    price_data = check_price_trigger(stocks)
    print(f"价量: {len(price_data)} 只成功")

    if quick:
        irm_data, notice_data, heat_data = [], [], []
    else:
        print(f"扫描互动易（近{days}天）...")
        irm_data = scan_irm(stocks, days)
        print(f"互动易: {len(irm_data)} 条")
        print("扫描公告...")
        notice_data = scan_notices(stocks, days)
        print(f"公告: {len(notice_data)} 条")
        print("检查人气榜...")
        heat_data = check_heat(stocks)
        print(f"人气榜: {len(heat_data)} 只")

    output = build_output(stocks, price_data, irm_data, notice_data, heat_data)
    json.dump(output, open(DATA / "latest.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    update_history(output)

    print(f"\n完成 | 扳机 {len(output['triggers'])} | 利好 {len(output['bullish'])} | 风险 {len(output['risks'])}")
    print(f"错误 {len(errors)} 条 | 数据源状态: {source_status}")
    print(f"输出: {DATA / 'latest.json'}")


if __name__ == "__main__":
    main()
