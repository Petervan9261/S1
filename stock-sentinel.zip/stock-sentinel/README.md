# 主升雷达 · 手机应用

一个依托 GitHub Actions + GitHub Pages 运行的每日股票监控 PWA，无需服务器。

## 架构

```
手机 PWA (GitHub Pages)  ←读取→  docs/data/latest.json
                                      ↑
                        GitHub Actions 每日定时扫描
                                      ↑
                              pool.txt 股票池
```

- **零服务器**：扫描在 GitHub Actions 免费的托管环境运行，结果提交回仓库，GitHub Pages 自动更新。
- **动态股票池**：编辑 `pool.txt` 即可增删股票，下次扫描生效。
- **PWA**：手机浏览器打开后"添加到主屏幕"，像原生 App 一样全屏使用。

## 四个信号源

| 信号 | 说明 | 限制 |
|---|---|---|
| 价量扳机 | 收盘突破 60 日高点 + 量比 > 1.5 | 执行信号 |
| 互动易 | 深市个股新问答中的利好/风险关键词 | 沪市不支持 |
| 公告 | 全市场公告按日扫描 + 本地关键词过滤 | 无精确时分 |
| 人气榜 | 东财人气排名飙升 = 减仓/回避信号 | — |

> 消息线索只进观察名单；价量扳机才是执行信号。

## 部署步骤

1. 用你的 GitHub 账号新建一个仓库，例如 `stock-sentinel`。
2. 把本目录所有文件上传到仓库（保持目录结构）。
3. 仓库 **Settings → Pages**：Source 选 `Deploy from a branch`，Branch 选 `main`，目录选 `/docs`，保存。
4. 打开 `https://<用户名>.github.io/stock-sentinel/` 即可访问。
5. 在 Actions 页面点 **Run workflow** 手动跑一次，验证扫描成功。
6. 手机浏览器打开上面的网址 → 菜单 → "添加到主屏幕"。

定时扫描默认每个工作日北京时间 08:00 和 15:30 各一次，可在 `.github/workflows/daily-scan.yml` 修改 cron。

## 修改股票池

编辑仓库根目录的 `pool.txt`，每行一个 `代码,名称`，`#` 开头是注释。也可以在 App 的"股票池"页编辑后导出，粘贴到 GitHub。

## 本地运行

```bash
pip install -r requirements.txt
python scanner/monitor.py          # 完整扫描
python scanner/monitor.py --quick  # 只跑价量扳机
```

## 文件结构

```
pool.txt                          股票池配置
scanner/monitor.py                扫描脚本
docs/index.html / style.css / app.js   PWA 前端
docs/manifest.json / sw.js / icon.svg  PWA 配置
docs/data/latest.json             最新扫描结果（自动生成）
docs/data/history.json            历史统计（自动生成）
.github/workflows/daily-scan.yml  定时工作流
```
