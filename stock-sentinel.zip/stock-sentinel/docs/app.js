// 主升雷达 - 前端逻辑
const DATA_URL = 'data/latest.json';
const HIST_URL = 'data/history.json';
const POOL_KEY = 'sentinel_pool_draft';
let latest = null, history = [];

// ---------- 工具 ----------
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}

// ---------- Tab 切换 ----------
$$('.tab').forEach(btn => btn.addEventListener('click', () => {
  $$('.tab').forEach(b => b.classList.remove('active'));
  $$('.panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  $('#tab-' + btn.dataset.tab).classList.add('active');
  if (btn.dataset.tab === 'history') renderHistory();
}));

// ---------- 加载数据 ----------
async function loadData() {
  try {
    const r1 = await fetch(DATA_URL + '?t=' + Date.now());
    latest = await r1.json();
    renderToday();
  } catch (e) {
    $('#scanTime').textContent = '数据加载失败';
    $('#noticeBar').textContent = '无法读取扫描数据，请确认 GitHub Actions 已成功运行。';
  }
  try {
    const r2 = await fetch(HIST_URL + '?t=' + Date.now());
    history = await r2.json();
  } catch (e) { history = []; }
}

// ---------- 今日信号 ----------
function renderToday() {
  if (!latest) return;
  $('#scanTime').textContent = '扫描 ' + (latest.scan_time || '').slice(5, 16);
  $('#noticeBar').textContent = latest.disclaimer || '';

  const tg = latest.triggers || [], bl = latest.bullish || [], rk = latest.risks || [];
  $('#summaryCards').innerHTML = `
    <div class="scard trigger"><div class="num">${tg.length}</div><div class="label">扣扳机</div></div>
    <div class="scard bull"><div class="num">${bl.length}</div><div class="label">利好线索</div></div>
    <div class="scard risk"><div class="num">${rk.length}</div><div class="label">风险提醒</div></div>`;
  $('#trigCount').textContent = tg.length;
  $('#bullCount').textContent = bl.length;
  $('#riskCount').textContent = rk.length;
  $('#poolCount').textContent = latest.pool_size || 0;

  $('#triggerList').innerHTML = tg.length ? tg.map(r => `
    <div class="item">
      <div class="item-head"><span class="item-name">${esc(r.name)}<span class="code">${esc(r.code)}</span></span>
      <span class="item-tag tag-up">✅ 扣扳机</span></div>
      <div class="item-text">现价 ${r.price} · 60日高 ${r.high60} · 量比 ${r.vol_ratio} · 涨幅 ${r.change}%</div>
      <div class="item-time">${esc(r.date || '')}</div>
    </div>`).join('') : '<div class="empty">今日无股票同时满足突破 + 放量</div>';

  $('#bullList').innerHTML = bl.length ? bl.map(r => `
    <div class="item">
      <div class="item-head"><span class="item-name">${esc(r.name)}<span class="code">${esc(r.code)}</span></span>
      <span class="item-tag tag-bull">${esc((r.signal||'').replace('利好:',''))}</span></div>
      <div class="item-text">${esc(r.text)}</div>
      <div class="item-time">${esc(r.source)} · ${esc(r.time)}</div>
    </div>`).join('') : '<div class="empty">无新增利好线索</div>';

  $('#riskList').innerHTML = rk.length ? rk.map(r => `
    <div class="item">
      <div class="item-head"><span class="item-name">${esc(r.name)}<span class="code">${esc(r.code)}</span></span>
      <span class="item-tag tag-risk">${esc(r.signal)}</span></div>
      <div class="item-text">${esc(r.text || '')}</div>
      <div class="item-time">${esc(r.source)} · ${esc(r.time || '')}</div>
    </div>`).join('') : '<div class="empty">无风险提醒</div>';

  const stocks = latest.stocks || [];
  $('#stockBody').innerHTML = stocks.map(s => {
    const chg = s.change;
    const chgCls = chg > 0 ? 'up' : (chg < 0 ? 'down' : 'dim');
    const chgTxt = chg != null ? (chg > 0 ? '+' : '') + chg + '%' : '-';
    let tags = '';
    if (s.trigger) tags += '<span class="st-tag st-break">扳机</span>';
    if (s.heat_signal && s.heat_signal.includes('飙升')) tags += '<span class="st-tag st-heat">热</span>';
    return `<tr class="${s.trigger ? 'trigger-row' : ''}">
      <td>${esc(s.code)}</td><td>${esc(s.name)}${tags}</td>
      <td>${s.price ?? '-'}</td><td class="${chgCls}">${chgTxt}</td>
      <td>${s.vol_ratio ?? '-'}</td><td>${s.heat_rank ?? '-'}</td>
      <td>${s.breakout ? '<span class="up">突破</span>' : '<span class="dim">-</span>'}</td>
    </tr>`;
  }).join('');

  const ss = latest.source_status || {};
  $('#sourceStatus').innerHTML = Object.entries(ss).map(([k, v]) =>
    `<span class="${v.fail === 0 ? 'src-ok' : 'src-fail'}">${k}:${v.ok}/${v.ok + v.fail}</span>`
  ).join('');
}

// ---------- 股票池编辑 ----------
function loadPoolEditor() {
  const draft = localStorage.getItem(POOL_KEY);
  if (draft) { $('#poolEditor').value = draft; return; }
  if (!latest) return;
  const text = latest.stocks.map(s => `${s.code},${s.name}`).join('\n');
  $('#poolEditor').value = text;
}
$('#saveLocalBtn').addEventListener('click', () => {
  localStorage.setItem(POOL_KEY, $('#poolEditor').value);
  toast('已保存到本机草稿');
});
$('#copyBtn').addEventListener('click', async () => {
  const text = $('#poolEditor').value;
  try { await navigator.clipboard.writeText(text); toast('已复制，去 GitHub 粘贴'); }
  catch (e) { toast('复制失败，请长按选择'); }
});
$('#exportBtn').addEventListener('click', () => {
  const text = $('#poolEditor').value;
  const blob = new Blob([text], {type: 'text/plain;charset=utf-8'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'pool.txt'; a.click();
  toast('已导出 pool.txt');
});
$('#resetPoolBtn').addEventListener('click', () => {
  localStorage.removeItem(POOL_KEY); loadPoolEditor(); toast('已恢复线上版本');
});
$('#addBtn').addEventListener('click', () => {
  const code = prompt('输入6位股票代码：');
  if (!code || !/^\d{6}$/.test(code)) { if (code) toast('代码需为6位数字'); return; }
  const name = prompt('输入股票名称（可留空）：') || '';
  $('#poolEditor').value += `\n${code},${name}`;
  toast('已添加，记得保存并同步到 GitHub');
});

// ---------- 历史 ----------
function renderHistory() {
  const list = $('#historyList');
  const data = history.slice(-30).reverse();
  if (!data.length) { list.innerHTML = '<div class="empty">暂无历史数据</div>'; return; }
  list.innerHTML = data.map(h => `
    <div class="item hist-item">
      <div><div class="hist-date">${esc(h.date)}</div>
      <div class="item-text">池内 ${h.pool_size} 只</div></div>
      <div class="hist-nums">扳机 <b class="up">${h.triggers}</b> · 利好 ${h.bullish} · 风险 ${h.risks}</div>
    </div>`).join('');
  drawChart();
}
function drawChart() {
  const cv = $('#historyChart'), ctx = cv.getContext('2d');
  const data = history.slice(-30);
  ctx.clearRect(0, 0, cv.width, cv.height);
  if (!data.length) return;
  const max = Math.max(1, ...data.map(d => d.triggers));
  const n = data.length, bw = cv.width / n;
  ctx.fillStyle = '#8b90a8'; ctx.font = '11px sans-serif';
  data.forEach((d, i) => {
    const h = (d.triggers / max) * (cv.height - 40);
    ctx.fillStyle = d.triggers > 0 ? '#ff5c6c' : '#2e3350';
    ctx.fillRect(i * bw + 2, cv.height - 20 - h, bw - 4, h);
    if (n <= 15 || i % 3 === 0) {
      ctx.fillStyle = '#8b90a8';
      ctx.fillText(d.date.slice(5), i * bw + 2, cv.height - 5);
    }
  });
}

// ---------- 启动 ----------
loadData().then(loadPoolEditor);
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
